# 🌐 React URL Shortener Frontend (Affordmed Evaluation)

![React](https://img.shields.io/badge/React-18-blue)
![Material UI](https://img.shields.io/badge/Material--UI-v5-blueviolet)
![License](https://img.shields.io/badge/license-MIT-green)

A frontend React application built for the Affordmed Campus Hiring Evaluation, providing a clean UI for shortening and managing URLs. This app integrates with the backend URL Shortener Microservice.

---

## 🎯 Features

- Shorten up to **5 URLs** concurrently
- Enter:
  - Original long URL
  - Optional expiry (in minutes)
  - Optional shortcode
- Display shortened results with expiry
- Display detailed **click analytics** per URL
- No `console.log` – uses **custom logging middleware**
- Built with **Material UI** for clean, responsive design

---

## 🚀 Getting Started

### 1. Clone the Repository

```bash
git clone https://github.com/YOUR_USERNAME/url-shortener-react.git
cd url-shortener-react
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Set Up Environment

Create a `.env` file with:

```env
REACT_APP_API_BASE_URL=http://localhost:3001
```

Ensure the backend service is running at the specified URL.

### 4. Start Development Server

```bash
npm start
```

App runs on: `http://localhost:3000`

---

## 📂 Project Structure

```
src/
├── components/
│   ├── URLForm.js        # Input form for shortening URLs
│   └── URLStats.js       # Display URL statistics
├── services/
│   ├── api.js            # Axios wrapper for API calls
│   └── logger.js         # Custom logging utility
├── App.js
└── index.js
```

---

## 📸 Screenshots

> You can paste UI screenshots here after running the app.

---

## 👨‍💻 Author

**Akshat Pandey**  
📧 akshat.22gcebcsd053@galgotiacollege.edu  
🎓 Roll No: 2200971650006  

---

## 📄 License

This project is licensed under the **MIT License**.