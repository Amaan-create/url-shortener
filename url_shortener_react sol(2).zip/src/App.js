import React from 'react';
import { Container, Typography } from '@mui/material';
import URLForm from './components/URLForm';
import URLStats from './components/URLStats';

function App() {
  return (
    <Container maxWidth="md" style={{ marginTop: '2rem' }}>
      <Typography variant="h4" gutterBottom>
        URL Shortener
      </Typography>
      <URLForm />
      <URLStats />
    </Container>
  );
}

export default App;