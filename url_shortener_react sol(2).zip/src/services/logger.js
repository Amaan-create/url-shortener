export default function logger(event, data) {
  const logEntry = {
    timestamp: new Date().toISOString(),
    event,
    data
  };
  const logs = JSON.parse(localStorage.getItem('logs') || '[]');
  logs.push(logEntry);
  localStorage.setItem('logs', JSON.stringify(logs));
}