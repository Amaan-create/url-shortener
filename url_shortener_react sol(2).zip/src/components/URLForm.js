import React, { useState } from 'react';
import { TextField, Button, Grid, Paper } from '@mui/material';
import api from '../services/api';
import logger from '../services/logger';

const URLForm = () => {
  const [entries, setEntries] = useState([
    { url: '', validity: '', shortcode: '' }
  ]);
  const [results, setResults] = useState([]);

  const handleChange = (index, field, value) => {
    const updated = [...entries];
    updated[index][field] = value;
    setEntries(updated);
  };

  const addEntry = () => {
    if (entries.length < 5) {
      setEntries([...entries, { url: '', validity: '', shortcode: '' }]);
    }
  };

  const handleSubmit = async () => {
    const promises = entries.map(async (entry) => {
      try {
        const res = await api.post('/shorturls', entry);
        logger('Shortened', res.data);
        return res.data;
      } catch (error) {
        logger('Error', error.response?.data || error.message);
        return { error: true, ...entry };
      }
    });
    const data = await Promise.all(promises);
    setResults(data);
  };

  return (
    <Paper style={{ padding: '1rem', marginBottom: '2rem' }}>
      {entries.map((entry, index) => (
        <Grid container spacing={2} key={index} style={{ marginBottom: '1rem' }}>
          <Grid item xs={12} sm={6}>
            <TextField
              label="Original URL"
              fullWidth
              value={entry.url}
              onChange={(e) => handleChange(index, 'url', e.target.value)}
              required
            />
          </Grid>
          <Grid item xs={3}>
            <TextField
              label="Validity (min)"
              type="number"
              fullWidth
              value={entry.validity}
              onChange={(e) => handleChange(index, 'validity', e.target.value)}
            />
          </Grid>
          <Grid item xs={3}>
            <TextField
              label="Shortcode"
              fullWidth
              value={entry.shortcode}
              onChange={(e) => handleChange(index, 'shortcode', e.target.value)}
            />
          </Grid>
        </Grid>
      ))}
      <Button variant="contained" onClick={addEntry} disabled={entries.length >= 5}>
        + Add URL
      </Button>
      <Button variant="contained" color="primary" onClick={handleSubmit} style={{ marginLeft: '1rem' }}>
        Shorten URLs
      </Button>
    </Paper>
  );
};

export default URLForm;