import React, { useState, useEffect } from 'react';
import { Typography, List, ListItem, ListItemText, Paper } from '@mui/material';
import api from '../services/api';
import logger from '../services/logger';

const URLStats = () => {
  const [stats, setStats] = useState([]);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const localUrls = JSON.parse(localStorage.getItem('shortened') || '[]');
        const promises = localUrls.map(async (item) => {
          const res = await api.get(`/shorturls/${item}`);
          logger('Stats', res.data);
          return { shortcode: item, ...res.data };
        });
        const data = await Promise.all(promises);
        setStats(data);
      } catch (err) {
        logger('Stats Error', err.message);
      }
    };
    fetchStats();
  }, []);

  return (
    <Paper style={{ padding: '1rem' }}>
      <Typography variant="h6" gutterBottom>Statistics</Typography>
      <List>
        {stats.map((item, index) => (
          <ListItem key={index}>
            <ListItemText
              primary={`${item.shortcode} → ${item.originalUrl}`}
              secondary={`Clicks: ${item.totalClicks} | Expires: ${item.expiry}`}
            />
          </ListItem>
        ))}
      </List>
    </Paper>
  );
};

export default URLStats;