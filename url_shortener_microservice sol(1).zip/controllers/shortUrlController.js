const ShortUrl = require('../models/ShortUrl');
const { generateShortCode, validateUrl } = require('../utils/helpers');

exports.createShortUrl = async (req, res) => {
    try {
        const { url, validity = 30, shortcode } = req.body;

        if (!validateUrl(url)) {
            return res.status(400).json({ error: 'Invalid URL format' });
        }

        let code = shortcode || generateShortCode();
        let existing = await ShortUrl.findOne({ shortcode: code });
        if (existing) {
            return res.status(409).json({ error: 'Shortcode already exists' });
        }

        const expiryDate = new Date(Date.now() + validity * 60000);
        const shortUrl = new ShortUrl({
            originalUrl: url,
            shortcode: code,
            expiry: expiryDate
        });

        await shortUrl.save();

        return res.status(201).json({
            shortLink: `http://localhost:3000/shorturls/${code}`,
            expiry: expiryDate.toISOString()
        });
    } catch (err) {
        return res.status(500).json({ error: 'Internal Server Error' });
    }
};

exports.getShortUrlStats = async (req, res) => {
    try {
        const { shortcode } = req.params;
        const record = await ShortUrl.findOne({ shortcode });

        if (!record) {
            return res.status(404).json({ error: 'Shortcode not found' });
        }

        return res.json({
            totalClicks: record.clicks.length,
            originalUrl: record.originalUrl,
            createdAt: record.createdAt,
            expiry: record.expiry,
            clicks: record.clicks
        });
    } catch (err) {
        return res.status(500).json({ error: 'Internal Server Error' });
    }
};