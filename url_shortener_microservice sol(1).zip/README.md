# 🔗 URL Shortener Microservice (Affordmed Evaluation)

![Node.js](https://img.shields.io/badge/Node.js-18.x-green.svg)
![MongoDB](https://img.shields.io/badge/MongoDB-Atlas%20or%20Local-brightgreen)
![Express](https://img.shields.io/badge/Express.js-fast-lightgrey)
![License](https://img.shields.io/badge/license-MIT-blue.svg)

This is a complete HTTP URL Shortener Microservice built for the **Affordmed Campus Hiring Evaluation**. It allows users to generate short URLs, track their usage, and manage expiry, all through a clean RESTful API.

---

## 🚀 Features

- 🔗 Shortens any valid URL
- 🕒 Configurable link expiry in minutes
- 📊 Tracks total click statistics
- 🧾 Logs every API request
- 🛠️ MongoDB (via Mongoose) for persistent storage
- 📂 Swagger and Postman collection included
- ✅ Clean project structure, production-ready

---

## 📦 Installation

```bash
git clone https://github.com/your-username/url-shortener-affordmed.git
cd url-shortener-affordmed
npm install
```

---

## ⚙️ Usage

### Start MongoDB (local):
```bash
mongod
```

### Start Server:
```bash
node server.js
```

---

## 🔌 API Endpoints

### `POST /shorturls` – Create a Short URL

```json
{
  "url": "https://example.com",
  "validity": 30,
  "shortcode": "custom123"
}
```

**Response:**
```json
{
  "shortLink": "http://localhost:3000/shorturls/custom123",
  "expiry": "2025-01-01T00:30:00Z"
}
```

---

### `GET /shorturls/:shortcode` – Retrieve Stats

**Response:**
```json
{
  "totalClicks": 0,
  "originalUrl": "https://example.com",
  "createdAt": "2025-06-27T10:00:00.000Z",
  "expiry": "2025-06-27T10:30:00.000Z",
  "clicks": []
}
```

---

## 📂 Project Structure

```
.
├── controllers/
├── models/
├── routes/
├── utils/
├── middlewares/
├── logs/
├── server.js
├── README.md
├── swagger.json
├── postman_collection.json
└── .gitignore
```

---

## 👨‍💻 Author

**Akshat Pandey**  
- Email: akshat.22gcebcsd053@galgotiacollege.edu  
- Roll No: 2200971650006  

---

## 📄 License

MIT License