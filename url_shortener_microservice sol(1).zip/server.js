const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const shortUrlRoutes = require('./routes/shortUrlRoutes');
const loggerMiddleware = require('./middlewares/logger');

const app = express();
app.use(bodyParser.json());
app.use(loggerMiddleware);
app.use('/shorturls', shortUrlRoutes);

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/urlshortener', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});