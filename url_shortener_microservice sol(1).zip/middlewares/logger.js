const fs = require('fs');
const path = require('path');
const logFilePath = path.join(__dirname, '../logs/requests.log');

module.exports = function (req, res, next) {
    const logEntry = `[${new Date().toISOString()}] ${req.method} ${req.originalUrl} - ${req.ip}\n`;
    fs.appendFile(logFilePath, logEntry, err => {
        if (err) console.error('Failed to log request:', err);
    });
    next();
};